# Entrega: Funnel "Las 10 reglas de oro de un equipo de limpieza"

Cliente: **Clear Onboarding**: plataforma de RR. HH. para dueñas de empresas de limpieza en EE. UU. (1 a 15 empleadas, hispanohablantes, todo desde el celular).
Objetivo: captar leads con una guía gratuita (PDF) y llevarlos a agendar una llamada de 15 minutos.

Recorrido: **Landing** → (envía formulario) → **Página de gracias** → **Correo de entrega** automático.

---

## 1. Qué hay en esta carpeta

```
entrega_antigravity_guia/
├── README.md                     ← este documento (fuente de verdad)
├── referencia/
│   ├── Landing Guia v2.dc.html   ← diseño final de la landing (abrir en el navegador)
│   ├── Gracias Guia v2.dc.html   ← diseño final de la página de gracias
│   ├── Correo Entrega Guia.html  ← correo HTML LISTO para enviar (tablas, inline)
│   ├── support.js / image-slot.js← solo para que las referencias abran localmente
│   └── assets/                   ← logos
└── assets/                       ← imágenes para producción (todas finales)
    ├── logo-color.png                        (logo a color, fondo transparente, 2948×904)
    ├── logo-white.png                        (logo blanco para fondos azul marino)
    ├── portada-ebook-10-reglas.webp          (355×460; mockup 3D del hero y de gracias. Pedir versión ≥ 1000 px de alto para pantallas retina)
    ├── caso-01-cada-una-a-su-manera.webp     (Caso 01, 704×704)
    ├── caso-02-nadie-recuerda-la-regla.webp  (Caso 02, 704×704)
    └── caso-03-renuncia-sorpresa.webp        (Caso 03, 704×704)
```

**Importante:** los archivos `.dc.html` son **referencias de diseño** (prototipos alta fidelidad). No se publican tal cual. La tarea es **reconstruirlos** como sitio de producción. El correo `Correo Entrega Guia.html` sí es HTML final: se pega en la herramienta de email.

Fidelidad: **alta**. Colores, tipografía, espaciados, textos y estados son finales. Copiar los textos **literalmente** (incluidos los testimonios, tal como los escribieron las clientas).

---

## 2. Stack recomendado

- Sitio estático: **Astro** (o HTML + Tailwind) publicado en **Vercel** o **Netlify** con HTTPS.
- Rutas:
  - `/guia` → Landing
  - `/guia/gracias` → Página de gracias
  - `/politica-de-privacidad` y `/terminos` (deben existir, aunque sea con el texto legal provisto por el cliente)
- Formulario: enviar a la herramienta de email marketing del cliente (variable `ESP_ENDPOINT`: MailerLite, ConvertKit, GoHighLevel, Brevo, etc.) vía función serverless (`/api/lead`). No exponer API keys en el cliente.
- Analítica: Meta Pixel + TikTok Pixel + GA4. Evento `Lead` al enviar con éxito; `ViewContent` en landing.
- Mobile first: la mayoría del tráfico llega desde Instagram, Facebook y TikTok (navegadores in-app). Probar en Safari iOS y en el navegador de Instagram.

### Variables a reemplazar

| Variable | Dónde |
|---|---|
| `[ENLACE_PDF]` | URL pública del PDF de la guía (gracias + correo) |
| `[ENLACE_AGENDA]` | Calendly / GHL / Google Calendar (gracias + correo) |
| `[DIRECCIÓN_POSTAL]` | Dirección física del remitente (correo, obligatorio CAN-SPAM) |
| `[ENLACE_BAJA]` | Link de baja que genera la herramienta de email |
| `[URL_LOGO]`, `[URL_MOCKUP_LIBRO]` | Imágenes alojadas en https para el correo |
| `ESP_ENDPOINT`, `ESP_API_KEY` | Herramienta de email (servidor) |

---

## 3. Sistema visual (tokens)

**Colores**
- Azul marino (principal): `#012B8B`
- Azul marino profundo (fondos oscuros): `#011E63`
- Azul intermedio (manchas de color): `#0A3AA6`
- Celeste (acentos y botones): `#009ED7` · hover `#0089BC`
- Celeste claro (fondos suaves): `#E3F8FE` · variante `#EEF9FD`
- Blanco `#FFFFFF`
- Texto oscuro `#1B2440` · texto secundario `#5A6785` · subtítulo hero `#3E4C6E`
- Bordes de campos `#C9D6E8` · bordes suaves `#E3EAF4`
- Error: borde `#D93B3B`, fondo campo `#FFF7F7`, texto `#C62828`, alerta fondo `#FFF1F1` texto `#9E1F1F`
- Celeste sobre fondo oscuro (etiquetas): `#8FDCF7`, `#A9DFF4`

**Tipografía:** Poppins (Google Fonts) 400 / 500 / 600 / 700 / 800.
- H1: 800, `clamp(28px, 4.4vw, 58px)`, line-height 1.06, letter-spacing -0.025em, `text-wrap: balance`
- H2: 800, `clamp(26px, 3.4vw, 42px)`, line-height 1.1, letter-spacing -0.02em
- Cuerpo: 400, 16 a 19px, line-height 1.5
- Etiquetas: 700, 12px, letter-spacing 0.14em, MAYÚSCULAS
- Inputs: 16px (evita zoom en iOS)

**Radios:** campos y botones 12 a 16px · tarjetas 20 a 26px · píldoras 999px.
**Contenedor:** max-width 1160px, padding lateral `clamp(20px, 5vw, 48px)`; secciones con padding vertical `clamp(56px, 8vw, 112px)`.

**Cristal líquido (glass claro)** — usado en menú, etiquetas, tarjetas, testimonios y "Quiénes somos":
```css
background: linear-gradient(135deg, rgba(255,255,255,.66), rgba(255,255,255,.30));
backdrop-filter: blur(22px) saturate(170%);
-webkit-backdrop-filter: blur(22px) saturate(170%);
border: 1px solid rgba(255,255,255,.75);
box-shadow: inset 0 1px 0 rgba(255,255,255,.95),
            inset 0 -10px 24px rgba(255,255,255,.20),
            0 24px 48px -24px rgba(1,43,139,.35);
/* brillo especular: ::before */
::before { content:''; position:absolute; inset:0; border-radius:inherit;
  background: radial-gradient(120% 70% at 15% 0%, rgba(255,255,255,.6), transparent 55%);
  pointer-events:none; }
```
**Glass oscuro** (sobre fotos / azul marino):
```css
background: linear-gradient(135deg, rgba(255,255,255,.20), rgba(255,255,255,.07));
backdrop-filter: blur(18px) saturate(160%);
border: 1px solid rgba(255,255,255,.28);
box-shadow: inset 0 1px 0 rgba(255,255,255,.45), 0 20px 40px -20px rgba(0,0,0,.45);
```
**Manchas de color**: círculos absolutos con `filter: blur(80–130px)` y opacidad 0.15–0.5 (ver cada sección en la referencia).
**Grano**: capa absoluta con ruido SVG (`feTurbulence baseFrequency .85`), opacidad 0.06 (`multiply`) en fondos claros y 0.12–0.14 (`overlay`) en oscuros. Evita el aspecto "demasiado perfecto".
**Botón principal**: `linear-gradient(180deg, #14B0E8, #009ED7 55%, #008FC4)`, borde `rgba(255,255,255,.35)`, sombra `inset 0 1px 0 rgba(255,255,255,.5), 0 14px 28px -10px rgba(0,158,215,.8)`; hover sube 1px.

Fallback: si el navegador no soporta `backdrop-filter`, usar `rgba(255,255,255,.88)` sólido.

---

## Imágenes del diseño
La portada y las 3 imágenes de los casos ya están en `assets/`. Los archivos de `referencia/` ya las muestran con `<img>`.

## 4. Landing (`/guia`)

Orden de secciones:

### 4.1 Menú flotante (sticky)
Píldora de cristal, `top: 10px`, max-width 1160, altura mínima 60. Izquierda: logo a color (alto 26–34px). Derecha: botón azul marino "Guía gratis" (alto 44, scroll suave al formulario). Se superpone al hero.

### 4.2 Hero — debe verse COMPLETO sin scroll en un celular de 390×844
- Fondo `#E3F8FE` + 3 manchas (celeste arriba-derecha, azul marino abajo-izquierda, blanca centro) + grano.
- Escritorio: texto a la izquierda, libro a la derecha. Celular: libro arriba (130px de ancho), texto debajo.
- Detrás del libro: número **"10"** gigante solo de contorno (`-webkit-text-stroke: 2px rgba(1,43,139,.13)`).
- **Mockup 3D del libro**: portada `assets/portada-ebook-10-reglas.webp` (ya entregada; `object-fit: cover`), `perspective:1400px`, `rotateY(26deg) rotateX(4deg) rotateZ(-2deg)`, lomo azul marino de 18px, sombra suave elíptica. Alternativa: exportar el mockup como PNG.
- 2 etiquetas de cristal flotando junto al libro: "10 reglas · una por página" (arriba-izquierda) y "Notas legales · OSHA · SHRM" (abajo-derecha), con check celeste.
- Etiqueta: **GUÍA GRATUITA**
- H1: **Las 10 reglas de oro de un equipo de limpieza** ("reglas de oro" con subrayado tipo marcador celeste 38%).
- Subtítulo: **Lo que tu equipo debe saber desde el primer día para que no pierdas clientes, empleadas ni tranquilidad.**
- Botón: **Quiero mi guía gratis** ↓ (scroll al formulario)

### 4.3 Dolor (fondo `#011E63`)
- H2 blanco: **¿Te suena familiar?** · nota a la derecha: "Casos recreados con IA. No son personas reales."
- 3 tarjetas de imagen vertical 4:5 (ancho 272–352px). En celular: carrusel horizontal con `scroll-snap`. En escritorio: 3 en fila centradas.
- Cada tarjeta: imagen IA a sangre + capa azul `mix-blend-mode: color` 30% + degradado inferior + grano + panel de cristal oscuro abajo con "CASO 0X" y el texto:
  1. Cada empleada trabaja a su manera y el cliente lo nota. *(imagen: dos empleadas limpian la misma cocina, cada una a su manera)*
  2. Corriges una falta y nadie recuerda la regla. *(imagen: la dueña corrige a una empleada que no recuerda la regla)*
  3. Una renuncia o una queja te toma por sorpresa. *(imagen: la dueña lee en su celular un mensaje de renuncia)*
- Imágenes (ya entregadas, `object-fit: cover` centrado, sin recorte especial): `assets/caso-01-cada-una-a-su-manera.webp`, `assets/caso-02-nadie-recuerda-la-regla.webp`, `assets/caso-03-renuncia-sorpresa.webp`. Alt = texto del caso. `loading="lazy"`.

### 4.4 Qué incluye (fondo `#EEF9FD`, mosaico tipo bento)
- H2: **Qué incluye la guía**
- Fila flexible (`flex-wrap`, gap 16): bloque grande azul marino (flex 2 1 520px) con "VISTA PREVIA DE PÁGINAS INTERIORES" y un abanico de 3 páginas (rotación -9°, 0°, 9°). Estilo de cada página: encabezado `#E3F8FE` con número grande celeste, caja azul marino con la regla y líneas grises de texto. **Usar las páginas reales del PDF** (los textos de la referencia son de ejemplo).
- 5 tarjetas de cristal (flex 1 1 240px) con check celeste y número 01–05:
  1. 10 reglas listas para enseñar, una por página
  2. Por qué importa cada regla y cómo se ve en la práctica
  3. Notas legales para la dueña basadas en ley federal, OSHA y SHRM
  4. Frases cortas para imprimir y pegar en el área del equipo
  5. Lista de pasos para aplicarlas esta semana

### 4.5 Testimonios (2 tarjetas de cristal, textos LITERALES)
- "gracias a tus instruciones estructurales que le han ayudado un montón en mi compañía / excelente programa" — **CMilena Herrera**, Fairy Legacy Clean · Kissimee, FL
- "Gracias Maye por todo lo que hace por nuestra empresa no lo puedo creer asta donde estamos llegando y ay más Dios la bendiga" — **Blanca Salgado**, Maid in The City - Friends · Hendersonville, NC
- (Ortografía pendiente de confirmar con el cliente. No inventar más testimonios ni cifras.)

### 4.6 Formulario (`id="formulario"`, fondo `#011E63` con manchas)
Tarjeta casi blanca (glass 95–86%), radio 26, max-width 580, padding `clamp(22px,4vw,40px)`, gap 20.
- Título: **Recibe la guía en tu correo** · "Los campos con * son obligatorios."
- Campos (alto 52, radio 12, borde 1.5px `#C9D6E8`, foco: borde `#009ED7` + halo `0 0 0 4px rgba(0,158,215,.15)`):
  - Nombre * (placeholder "Ej. María")
  - Correo electrónico * (type email)
  - Nombre de tu empresa * ("Ej. Sparkle Cleaning LLC")
  - Estado donde operas * (select con los 50 estados, opción vacía "Elige un estado")
  - WhatsApp (opcional) (type tel)
- **¿Cuántas personas trabajan contigo?** — selección única en botones: 1 a 5 / 6 a 10 / 11 a 15 / Más de 15. Seleccionado: fondo y borde `#012B8B`, texto blanco. Opcional.
- **¿Qué te quita más el sueño hoy?** (Puedes marcar varias) — casillas: Rotación y renuncias · Quejas de clientes · Faltas y llegadas tarde · Papeles y documentos de las empleadas · Capacitar a las nuevas. Marcada: caja `#009ED7` con check blanco, fila fondo `#F0FAFE` borde `#009ED7`.
- **Consentimientos — SIN marcar por defecto, separados:**
  1. Acepto recibir la guía y correos de Clear Onboarding con recursos para mi empresa. Puedo darme de baja cuando quiera. *(obligatoria)*
  2. Acepto recibir mensajes por WhatsApp o SMS de Clear Onboarding. Pueden aplicar tarifas de mensajes y datos. Responde STOP para cancelar. *(opcional, SOLO visible si el campo WhatsApp tiene texto)*
  3. He leído la Política de Privacidad *(enlace a /politica-de-privacidad, obligatoria)*
- Botón: **Enviarme la guía** (alto 56). Mientras envía: "Enviando…" y deshabilitado.
- Debajo con candado: **Tus datos están seguros. No compartimos tu información.**

**Validación** (al enviar; después del primer intento, valida en vivo):
- Nombre vacío → "Escribe tu nombre."
- Correo vacío → "Escribe tu correo electrónico." · inválido → "Revisa tu correo. Ejemplo: maria@gmail.com"
- Empresa vacía → "Escribe el nombre de tu empresa."
- Estado vacío → "Elige el estado donde operas."
- Consentimiento 1 → "Necesitamos tu permiso para enviarte la guía."
- Consentimiento 3 → "Confirma que leíste la Política de Privacidad."
- Campo con error: borde `#D93B3B`, fondo `#FFF7F7`, mensaje 13px `#C62828` con ícono. Arriba del botón: alerta "Revisa los campos marcados en rojo."
- Éxito → POST a `/api/lead` → redirigir a `/guia/gracias`.

**Datos a guardar por lead:** nombre, correo, empresa, estado, whatsapp, tamaño de equipo, preocupaciones (array), consent_email, consent_sms, consent_privacidad, **fecha/hora, IP, URL, user agent y texto exacto de cada consentimiento** (evidencia TCPA/CAN-SPAM), UTM (`utm_source`, `utm_medium`, `utm_campaign`, `utm_content`). Etiquetar en el ESP por tamaño de equipo y por preocupación.

### 4.7 Quiénes somos
Panel de cristal centrado (max 820), logo a color y texto: **Clear Onboarding organiza la contratación, el primer día, las comunicaciones y el expediente de cada empleada en un solo lugar, desde su celular.**

### 4.8 Footer (fondo `#012B8B`)
Logo blanco (alto 32) · enlaces "Política de Privacidad" y "Términos" · "© 2026 Clear Onboarding" (año dinámico).

### 4.9 Barra fija inferior (solo celular, < 760px)
Píldora de cristal fija abajo (12px de margen) con botón "Quiero mi guía gratis". Aparece después de pasar el hero y se oculta cuando el formulario está visible.

---

## 5. Página de gracias (`/guia/gracias`)

- Mismo menú flotante (solo logo) y mismo fondo del hero.
- Libro 3D a la derecha (escritorio) / arriba (celular).
- Círculo celeste con check blanco.
- H1: **¡Listo! Tu guía va camino a tu correo.**
- Texto: **Revisa tu bandeja de entrada y la carpeta de promociones o spam. Si no llega en 5 minutos, descárgala aquí.** ("descárgala aquí" enlaza a `[ENLACE_PDF]`)
- Botón principal: **Descargar la guía ahora** → `[ENLACE_PDF]`
- Bloque azul marino (radio 26, mancha celeste + grano): **¿Quieres ver cómo se aplican estas reglas con tu equipo en Clear Onboarding?** + botón celeste **Agendar llamada rápida (15 minutos)** → `[ENLACE_AGENDA]`
- Footer igual a la landing.
- Disparar evento `Lead` de los píxeles aquí si no se disparó antes. `noindex`.

---

## 6. Correo de entrega

Archivo final: `referencia/Correo Entrega Guia.html` (600px, tablas, estilos en línea, compatible con Gmail y Outlook, sin efecto de cristal porque los clientes de correo no lo soportan).
- Asunto A: **Aquí están tus 10 reglas de oro, {Nombre}**
- Asunto B (prueba A/B): **Tu guía para que tu equipo trabaje como uno solo**
- Preheader: **Léela hoy con tu equipo. Te toma 10 minutos.**
- Reemplazar `{Nombre}` por la etiqueta de personalización del ESP y las variables de la sección 2.
- Reemplazar el `src` del logo por una URL https y la celda de "mockup del libro" por `<img src="[URL_MOCKUP_LIBRO]" width="300" alt="Guía: Las 10 reglas de oro de un equipo de limpieza">`.
- Enviar automáticamente al crear el lead. Remitente: Luma, Clear Onboarding.

---

## 7. Requisitos legales y de calidad

- Consentimientos separados y sin marcar (TCPA para SMS/WhatsApp, CAN-SPAM para email).
- Políticas de Privacidad y Términos publicadas antes de lanzar.
- Accesibilidad: contraste, `label` en cada campo, foco visible, objetivos táctiles ≥ 44px, `aria-live` en errores.
- Rendimiento: imágenes en WebP/AVIF con `loading="lazy"` (excepto portada), fuente con `display=swap`, objetivo LCP < 2.5 s en 4G.
- SEO/compartir: título "Las 10 reglas de oro de un equipo de limpieza | Clear Onboarding", meta description con el subtítulo, imagen Open Graph 1200×630 con el libro.

---

## 8. Pendiente (no implementar todavía, dejar preparado)

**Video de TikTok relacionado con los casos**
- En el hero: una píldora de cristal pequeña debajo del botón, tipo "▶ Mira el caso en 40 segundos", que abre el video en un modal (no ocupa espacio en el hero).
- Después de la sección 4.3 (Dolor): bloque "Este caso lo contamos en TikTok" con el video vertical 9:16 a un lado y botón al formulario.
- Usar MP4 propio con portada (no el embed de TikTok) + enlace a la cuenta.
- Falta: el video, el texto de la píldora y el enlace de TikTok.

## 9. Material que falta del cliente
- El PDF final de la guía
- Textos reales de las 3 páginas de vista previa
- `[ENLACE_AGENDA]`, `[DIRECCIÓN_POSTAL]`, herramienta de email
- Confirmar ortografía de los testimonios
